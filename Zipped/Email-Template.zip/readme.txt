Project Name: Your Trial Has Expired - Email Template

This is the readme file for the OpDemand "Your Trial Has Expired" email template.

File should be suitable for Mac Mail as well as Microsoft Outlook.

By: Ben Grunfeld
Date Created: 4/2/2013 - 3:24

